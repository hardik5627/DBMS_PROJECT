<!DOCTYPE html>
<html lang = "en">
<head>
    <meta charset = "UTF-8">
    <meta name="viewport" content ="width =device-width , initial-scale=1.0">
    <title>Cab Booking</title>
</head>

<h1>Book Cab</h1>

<body>
    <div><h2></h2></div>
    <form action = 'connect2.php' method ="POST">
        <label for ="pickup">Enter Pickup Location:</label><br>
        <input type ='text' name = 'pickup' id = "pickup" required/><br>
        <label for ="destination">Enter Drop Location: </label><br>
        <input type = 'text' name = 'drop' id = "drop" required/><br>

        <input type ='submit' name = 'submit' id ="submit" />
    </form>
</body>
</html>
