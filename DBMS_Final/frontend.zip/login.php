<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <!-- <meta http-equiv="X-UA-Compatible" content="IE=edge"> -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <h1>Cab Site</h1>
    <h2>Please Login</h2>
    <form action="" method="post">
        <label for="uname">Enter your Username</label><br>
        <input type="text" name="uname"/> <br><br>
        <label for="pwd">Enter Password</label><br>
        <input type="password" name="pwd"><br><br>
        <input type="submit" name="login_submit" value="Log In">
    </form>
</head>
<body>
    
</body>
</html>
<?php
error_reporting(0);
session_start();
    $uname=$_POST['uname'];
    $pswd=$_POST['pwd'];
    $conn=mysqli_connect('localhost', 'root', '') or die(mysqli_error());
    $db='Ola';
    $sql="SELECT CustID, UserName, PassW FROM Customers WHERE UserName='$uname' AND PassW ='$pswd'";
    $res=mysqli_query($conn, $sql);
    $row=mysqli_fetch_array($res, MYSQLI_ASSOC);
    if(mysqli_num_rows($res)){
        $id=mysqli_fetch_assoc(mysqli_query($conn,"SELECT CustID FROM Customers WHERE UserName ='$uname AND passW='$pswd''"));
        $_SESSION['id']=$id['CustID'];
        $_SESSION['uname']=$uname;
        header('location: book.php');//redirect to the booking page from here
    }
    else{
        echo " Something went again! Refresh and try again!";
    }

?>