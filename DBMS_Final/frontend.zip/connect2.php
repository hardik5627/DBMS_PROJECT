<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['submit'])){
$servername = "localhost";
$username = "root";
$password = "";
$db = "Ola";
// Create connection
$conn = new mysqli($servername, $username, $password ,$db);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  } 
  if(isset($_POST['pickup']) && isset($_POST['drop'])){
    $pickup= $_POST['pickup'];
    $destination = $_POST['drop'];
    $driveID = rand(1,11);
    $CusID = $_SESSION['a'];
    $dist = rand(1,10);
    $_SESSION['b'] = $dist;
    $_SESSION['c'] = $driveID;
// Check connection
$sql =  "INSERT INTO Trips (Pickup , Destination ,CustID , DriverID ,Distance) VALUES ('$pickup' , '$destination' , $CusID , $driveID ,$dist);";


$result = mysqli_query($conn,$sql);

    if(!$result) {
        die('There was an error running the query [' . $db->error . ']');
    }

    else {

        echo "Successful query.";
        echo nl2br("\n Distance is: ".$dist);
        echo nl2br("\nEstimated Fare: ".($dist * 10) + 40);
        //header("Location: booked.php");
        

    }
}
}
?>