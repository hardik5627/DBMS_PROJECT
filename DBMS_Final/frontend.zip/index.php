<!DOCTYPE html>
<html lang = "en">
<head>
    <meta charset = "UTF-8">
    <meta name="viewport" content ="width =device-width , initial-scale=1.0">
    <title>Cab Booking</title>
</head>

<h1>Welcome to IIITD Cab Booking</h1>
<body>
    <div><h2>Sign Up</h2></div>
    <form action = 'connect.php' method ="POST">
        <label for ="FName">First Name:</label><br>
        <input type ='text' name = 'name' id = "name" required/><br>
        <label for ="Last">Last Name: </label><br>
        <input type = 'text' name = 'Lname' id = "Lname" required/><br>
        <label for ="phone">Phone:</label><br>
        <input type ='text' name = 'phone' id = "phone" required/><br>
        <label for ="user">User Name:</label><br>
        <input type ='text' name = 'Uname' id = "Uname" required/><br>
        <label for ="pass">Password:</label><br>
        <input type ='text' name = 'passw' id = "passw" required/><br>

        <input type ='submit' name = 'submit' id ="submit" />
        
    </form>
    <form action = 'login.php' method = "POST">
    <button type="submit">Login Instead</button>
</body>
</html>
