<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['submit'])){
$servername = "localhost";
$username = "root";
$password = "";
$db = "Ola";
// Create connection
$conn = new mysqli($servername, $username, $password ,$db);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  } 
  if(isset($_POST['name']) && isset($_POST['Lname']) && isset($_POST['phone']) && isset($_POST['Uname']) && isset($_POST['passw'])){
    $name= $_POST['name'];
    $Lname = $_POST['Lname'];
    $phone = $_POST['phone'];
    $Uname = $_POST['Uname'];
    $passw = $_POST['passw'];

// Check connection
$sql =  "INSERT INTO Customers (CustFirstName , CustLastName ,UserName ,PassW , Phone) VALUES ('$name' , '$Lname' ,'$Uname ','$passw' ,'$phone')";
//$sql = "INSERT INTO Customers( CustFirstName, `CustLastName`, `UserName`, `PassW`, `Phone`) VALUES ('[value-1]','[value-2]','[value-3]','[value-4]','[value-5]','[value-6]')"

$result = mysqli_query($conn,$sql);

    if(!$result) {
        die('There was an error running the query [' . $db->error . ']');
    }

    else {

        //echo "Successful query.";
        $last_id = $conn->insert_id;
        $_SESSION['a'] = $last_id;
        echo "New record created successfully. Last inserted ID is: " . $last_id;
        
        //echo rand(1,11);
        header('Location: book.php');

    }
}
}
?>
